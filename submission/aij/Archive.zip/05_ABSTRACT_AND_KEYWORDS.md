# PHASE 5 — ABSTRACT AND KEYWORDS AUDIT

**Target Journal**: *Artificial Intelligence* (AIJ)  

---

## 1. Locked Abstract

> Standard evaluations of reinforcement-learning post-training in large language models emphasize aggregate benchmark accuracy, potentially obscuring changes conditional on local reasoning state. We introduce **StateShift**, a framework for measuring target-transition recovery under matched reasoning states. In a controlled study ($N=454, 29,056$ rollouts), we observe an 11.76-percentage-point state-by-checkpoint interaction between the base and step-256 checkpoints ($\Gamma_{256}=0.1176, 95\%$ problem-blocked bootstrap CI $[0.0955, 0.1400]$). Across nine empirically evaluated checkpoints, the interaction was consistent with a non-decreasing trajectory under prespecified order-restricted analysis despite local variation in unconstrained estimates, and was already detectable at the earliest available post-training checkpoint, $t=32$ ($\Gamma_{32}=0.0333$, multiplicity-adjusted 95\% CI $[0.0011, 0.0655]$). In a separate analysis of 3,200 unperturbed rollouts, 18.19\% contained a verifier-confirmed natural reasoning error; among 582 qualifying error episodes, 180 subsequently satisfied the prespecified autonomous recovery criterion ($30.93\%$, 95\% problem-blocked bootstrap CI $[27.19\%, 34.82\%]$). These results show that state-conditioned evaluation exposes behavioral structure not captured by aggregate correctness alone.

---

## 2. Approved Keywords (6 Keywords)

1. `Large language models`
2. `Reinforcement learning`
3. `Mathematical reasoning`
4. `Reasoning recovery`
5. `Post-training evaluation`
6. `State-conditioned evaluation`

*Signed by Senior Scientific Writer & Technical Editor*
